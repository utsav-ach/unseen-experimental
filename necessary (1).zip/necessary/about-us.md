## Features of the app:

1. Admins registers the top destinations for travelling,
2. Users choose from those destinations
3. tourist hire guide who can goto that destination
4. booking is done, and thats the overall flow,
5. There a predefined sets of packages that admin puts and tourist can choose from them,
6. Tourist can choose famous activities and plan trip to them.

### Extra features:

You dont always have to book from featured destinations, you are free to choose any location via map in `components/map/selection-map.tsx`

then we will use the geo spatial data to determine the guide whose service area is within the place you wanna go,

you choose any one of the guide and you are good to go,

Also if you are a tourist who dont want to be bothered with this long process you can also choose from predefined packages like `Holiday package` where you just do the booking and we will contact you ourself to proceed.

## But How does guide gets selected ?

We dont force a guide for your own trip, we give you full flexibility to choose anyone from the list.

## How are guide shown in platform ?

For a person to be shown as guide in the platform he/she must send a application to apply for the guide, the application is then viewed by our admins, and either approved or rejected,  
admin must provide a nice feedback message in either reject/accept to the guide, like 'congratulations' or even deep on why he was rejected,

once approved by admin then they are shown in the UI.

## What are packages ?

Packages are predefined set of travel destinations with especific guide, price and locations already choosen. Our admin puts these packages and you choose from any one of them and go on trip.

There is no hassle of negotiations or anything, and the best thing, we call you ourself and explain you everything ourself just for this 2nd step of understanding.

## What are activities then ?

Activities are nothing just a wrapper around featured destinations. Ever wanted to goto fishing but you dont know where to go ? So we choose places where fishing is possible and rest is upto you.

When you goto activities and choose any one activity then you see list of featured destinations where that is possible,

and rest is same process, choose guide negotiate and so on.

In short package is only something quite different then others, where there is no negotiation,

## Flow of Booking

for booking a guide for your travel there involves 3 step negotiation flow,

1. You choose a guide and sends a hire request.
   during the request you fill some details, like, destinations place you wanna go, no of people, Durations of days, and some additional remarks or feedbacks,

2. The application is shown to the guide in their dashboard page (yes the guide gets his own dashboard page where applications are listed) and then he clicks on any of the applications and then he is taken to the details page of the application from where he can either approve or reject the client,
   same here is also a remark is mandatory in each case,  
   if he rejects then the client is shown rejected,
   but if guide accepts then he should fill 3 things,

- remarks
- Total fees
- Pre Payment

**Wait we take fees here ?**
Ohh yes, because for a guide the fees is not constant, suppose one guide is going to biratnagar from itahari then the fees in that case is obviously different from going from itahari to pokhara.  
so there is no hourly rate or daily rate for guide, this is the most realistic pattern that travel agencies use,  
Guide is free to put any cost he likes, after reviewing the destination and no of days or people,
For same destination he can charge different amount too,

**Wait there is more its not finished yet,**

3. Now after the guide sent the remarks and demanded certain amount and total amount
   now the user will review his request, and then finally Cancel negotiation or Complete the booking,
   if he plans to cancel then the guide will be shown cancelled.

if the tourist/user plans to complete the booking then he must pay the amount the guide requested at least,  
**what i mean by at least ?**
It means the user can pay min of prepay amount guide want upto max of the total amount,

If he pays the amount then only the booking is recorded and considered complete.

Wooh its too much hassle right ?
Naah, i dont think so, because Guide are also humans we should understand their emotions too, so this is the best flow for both user and guide

## Other features

thats all our features for now,

the user chooses a destination or choose a place in map
then chooses a guide and then follow the TSN `Three step NEgotiation`

### Travel Packages (Direct Booking)

For tourists who prefer pre-planned trips, Admins create "Featured Packages". These have fixed prices, routes, and capacities. Booking a package is direct and skips the negotiation phase.

### Travel activities (or activities-packages) (Same as packages)

the concept of the activities is also same as packages, Admin created the list of activities our company provides, like `Fishing` the activities also has fixed prices, routes, no negotiation phase. Basically what we can say is activities are basically a `marketing scheme` and nothing just travel packages in disguise.

### Stories sharing

Our app also provides a platform for our users to share their travel or life stories, they are free to share their experience of life or journey and we will show them in our platform, other users can also interact with it via likes and comments.

### Photos sharing

Sometime user may not feel like to write stories he just want to share his photos and memories to public with short description in that case we also provide a photo platform where they can share their photos to the public

**Wait ain't it same as stories, if we have to put descriptions ?**
Yes you are right it actually is, but in photos the decription is optional and there is no way of interaction here, its upload and forget.

---

### These were the information of the project, now lets go on the coding.
