# Setup script for unseen-nepal-frontend

Write-Host "Starting setup script for Windows..."

# Check and install git
if (-not (Get-Command -Name "git" -ErrorAction SilentlyContinue)) {
    Write-Host "Git is not installed. (Devloper vayera halna pardaina huh ? ) ..." -ForegroundColor Red
    $answer = Read-Host "Git Haldem ta aafai install ? (Y/n) "
    if ($answer -eq "Y" -or $answer -eq "y") {
        Write-Host "Lah theek xa good decision, Narayan le rakhsa garun" -ForegroundColor Yellow
        winget install --id Git.Git -e --source winget
    } else {
        Write-Host "haha! Prank  hogaya,  Git ta  haldenxu ma aafai na vaye ni " -ForegroundColor Yellow
        winget install --id Git.Git -e --source winget
    }
    
    # Refresh environment variables to use git right away
    $env:PATH = [System.Environment]::GetEnvironmentVariable("Path","Machine") + ";" + [System.Environment]::GetEnvironmentVariable("Path","User")
} else {
    Write-Host "Waau, Git raxa already Devloper guy noice...." -ForegroundColor Green
}

Write-Host "Aaba Nepali vayo hai, aalik professional hos,  English aaba pure..." -ForegroundColor Cyan


# Check and install bun
if (-not (Get-Command -Name "bun" -ErrorAction SilentlyContinue)) {
    Write-Host "You dont have bun, approaching to install." -ForegroundColor Red
    powershell -c "irm bun.sh/install.ps1|iex"
    
    # Try to add Bun to the current session's PATH
    $bunBin = "$env:USERPROFILE\.bun\bin"
    if (Test-Path $bunBin) {
        $env:PATH += ";$bunBin"
    }
} else {
    Write-Host "Bun is already installed." -ForegroundColor Green
}

# Clone repository
$TargetDir = "$env:USERPROFILE\Desktop\unseen-nepal-frontend"

if (Test-Path $TargetDir) {
    Write-Host "Directory $TargetDir already exists. Skipping git clone." -ForegroundColor Green
} else {
    Write-Host "Cloning unseen-nepal-frontend into $TargetDir..."
    git clone https://github.com/Utsav-56/unseen-nepal-frontend.git "$TargetDir"
}

# Setup project
Write-Host "Entering directory $TargetDir..."
Set-Location -Path $TargetDir

Write-Host "Running bun install to install project dependencies..."
bun install

Write-Host "Creating the ./commit.ps1 helper script..."
$commitContent = @"
`$message = Read-Host "Enter the commit message"
git add .
git commit -m "`$message"
"@
Set-Content -Path ".\commit.ps1" -Value $commitContent

$pushContent = @"
# first check if the git status is clean
if (git status --porcelain) {
    # now call the commit script
    .\commit.ps1
}

# Now check if the remote and local are in sync
if (git rev-parse HEAD) != (git rev-parse @{u}) {
    Write-Host "Remote and local are not in sync. Please pull first to sync." -ForegroundColor Red
    # ask user if he wants to pull
    $answer = Read-Host "Do you want to pull the changes from github ? (y/n) "
    if ($answer -eq "y" -or $answer -eq "Y") {
        git pull
    }
}

# Then push
git push
"@
Set-Content -Path ".\push.ps1" -Value $pushContent

Write-Host "Removing the setup scripts..."
Remove-Item -Path ".\setup.ps1" -Force -ErrorAction SilentlyContinue
Remove-Item -Path ".\setup.sh" -Force -ErrorAction SilentlyContinue
# Also try to remove from the current location if script was run before clone
if (Test-Path $PSCommandPath) { Remove-Item -Path $PSCommandPath -Force -ErrorAction SilentlyContinue }

# Trickiest part: VS Code Check
$vscodeFound = $false

if (Get-Command -Name "code" -ErrorAction SilentlyContinue) {
    Write-Host "VS Code is available in PATH."
    $vscodeFound = $true
} else {
    Write-Host "VS Code not found in PATH. Searching common paths..."
    $commonPaths = @(
        "$env:LocalAppData\Programs\Microsoft VS Code\bin",
        "$env:ProgramFiles\Microsoft VS Code\bin",
        "${env:ProgramFiles(x86)}\Microsoft VS Code\bin"
    )
    foreach ($path in $commonPaths) {
        if (Test-Path "$path\code.cmd") {
            $vscodeFound = $true
            # Add to PATH
            $env:PATH += ";$path"
            $userPath = [Environment]::GetEnvironmentVariable("PATH", "User")
            [Environment]::SetEnvironmentVariable("PATH", "$userPath;$path", "User")
            Write-Host "Found VS Code in common paths and added to PATH."
            break
        }
    }
    
    if (-not $vscodeFound) {
        Write-Host "Searching for VS Code in Start Menu..."
        $startMenuPath1 = "$env:APPDATA\Microsoft\Windows\Start Menu\Programs"
        $startMenuPath2 = "$env:ALLUSERSPROFILE\Microsoft\Windows\Start Menu\Programs"
        
        $shortcut = Get-ChildItem -Path $startMenuPath1, $startMenuPath2 -Filter "Visual Studio Code*.lnk" -Recurse -ErrorAction SilentlyContinue | Select-Object -First 1
        
        if ($shortcut) {
            $shell = New-Object -ComObject WScript.Shell
            $lnk = $shell.CreateShortcut($shortcut.FullName)
            $targetPath = $lnk.TargetPath
            if (Test-Path $targetPath) {
                $binDir = Join-Path (Split-Path $targetPath) "bin"
                if (Test-Path "$binDir\code.cmd") {
                    $vscodeFound = $true
                    $env:PATH += ";$binDir"
                    $userPath = [Environment]::GetEnvironmentVariable("PATH", "User")
                    [Environment]::SetEnvironmentVariable("PATH", "$userPath;$binDir", "User")
                    Write-Host "Found VS Code via Start Menu and added to PATH."
                }
            }
        }
    }
}

if (-not $vscodeFound) {
    Write-Host "VS Code could not be found."
} else {
    Write-Host "Installing VS Code extensions..."
    code --install-extension dbaeumer.vscode-eslint `
    && code --install-extension esbenp.prettier-vscode `
    && code --install-extension eamodio.gitlens `
    && code --install-extension christian-kohler.path-intellisense `
    && code --install-extension usernamehw.errorlens `
    && code --install-extension dsznajder.es7-react-js-snippets `
    && code --install-extension bradlc.vscode-tailwindcss `
    && code --install-extension formulahendry.auto-rename-tag ` 
    && code --install-extension wix.vscode-import-cost `
    && code --install-extension yoavbls.pretty-ts-errors
}

# creating bat file on desktop
Write-Host "Creating open-unseen-nepal.bat on Desktop..."
$batContent = @"
@echo off
cd /d "%USERPROFILE%\Desktop\unseen-nepal-frontend"

echo Checking if remote and local are in sync...
git fetch

for /f "tokens=*" %%i in ('git rev-parse HEAD') do set LOCAL_COMMIT=%%i
for /f "tokens=*" %%i in ('git rev-parse @{u}') do set REMOTE_COMMIT=%%i

if "%LOCAL_COMMIT%"=="%REMOTE_COMMIT%" (
    code .
    exit /b
)

echo Remote and current branch are not in sync (Github ma change aako xa  kasiale code edit upload garexa)!
echo Timi haru 2 janai le aalag aalag file change gareko xa vane no issues ki
echo tara same file edit xa vane chai ekxin (Leader) lai garo  merger solve garna
echo So timle aalik crucial file ma kaam xa vane chai sync na gara hai
set /p DO_SYNC="Do you want to sync now? (y/n): "
if /i "%DO_SYNC%"=="y" (
    git pull
)

code .
"@
Set-Content -Path "$env:USERPROFILE\Desktop\open-unseen-nepal.bat" -Value $batContent

Write-Host "Setup script finished successfully."


$mainMessage = @"
Ani main kura, 
env file beena chaldaina yo project backend nai khuldaina ki, 
so utsav-56 lai env file magne hai, 
env file is secret yo leak hunu means backend nai khuldaina hai, 
"@