# Guide + Destination Alignment Execution Plan (Post Architecture Shift)

## Scope locked for this execution
- Guides domain (schema-driven RPC + services + stores + UI)
- Destinations integration points that depend on guides
- Frontend contracts consuming guide and destination guide payloads
- No booking-module redesign in this pass (as requested)

## Schema-first constraints from new `sql/schema/guides.sql`
1. Guide table now uses `description`, `previous_experience`, `known_languages`, `admin_feedback`, `is_available`, `is_suspended`, `avg_rating`.
2. Guide applications now use `application_id`, `nid_document_type`, `nid_number`, `nid_photo_url`.
3. New tables involved: `guide_service_areas_applications`, `suspended_guides`, `unsuspension_requests`, `guide_reviews`.
4. Guide listing should rely on views (`guide_profiles`, `available_guides`) + RPC behavior.

## Execution steps
1. **Repair SQL schema correctness for guides**
   - Fix structural issues in `sql/schema/guides.sql` (invalid refs/columns/commas/field naming mismatches).
   - Keep final schema consistent with your new architecture text.

2. **Replace guide RPC layer with new canonical RPCs**
   - Implement mandatory RPCs:
     - `apply_guide_application`
     - `change_guide_application_status`
     - `submit_unsuspension_request`
     - `change_unsuspension_request_status`
   - Add guide listing/detail RPCs aligned with new columns (`description`, `guide_reviews`, `is_suspended`).
   - Remove/stop depending on stale guide RPC contracts that use old columns (`bio`, `location`, `reviews`, etc.).

3. **Align destination RPCs where they embed guide data**
   - Update destination details guide join/filter to use new guide schema + guide view.
   - Keep destination output contract stable for existing destination UI where possible.

4. **Refactor guide frontend logic layer from scratch contract-wise**
   - Update guide schemas (`backend/modules/guide-models.ts`) to new DB fields.
   - Rewrite guide services (`guideService`, `guideApplicationService`) to call new RPCs and stop old direct table assumptions.
   - Rewrite guide stores (`useGuideStore`, `useGuideApplicationStore`, `useTrekDaiStore`) to new service contract.

5. **Update guide-facing UI + admin guide-application UI**
   - Update `/guide/register`, `/guide/register/status`, trek-dai pages, guide cards/details.
   - Update admin guide application screens to new fields (`application_id`, `nid_*`).
   - Preserve clean user-side design and error rendering rules.

6. **Manifest/changelog sync + typecheck**
   - Update `changelog.md` with this architecture migration.
   - Update `AGENTS.md` manifest sync paragraph for new guide architecture expectations.
   - Run Bun TypeScript check and resolve any introduced type errors.
