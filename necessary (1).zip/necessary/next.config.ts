import type { NextConfig } from "next";

const nextConfig: NextConfig = {
	output: "standalone",
	images: {
		remotePatterns: [
			{
				protocol: "https",
				hostname: "images.unsplash.com",
			},
			{
				protocol: "https",
				hostname: "gwhfdibumtvrritxpoxp.supabase.co",
			},
			{
				protocol: "https",
				hostname: "lh3.googleusercontent.com",
			},
			{
				protocol: "https",
				hostname: "gwhfdibumtvrritxpoxp.supabase.co",
				pathname: "/storage/v1/object/public/stories_images/**",
			},
			{
				protocol: "https",
				hostname: "ui-avatars.com",
			},
			{
				protocol: "https",
				hostname: "api.dicebear.com",
			},
		],
	},
	allowedDevOrigins: ["*"],
	// enablePrerenderSourceMaps: true,
	productionBrowserSourceMaps: true,
	experimental: {
		serverSourceMaps: true,
	},
};

export default nextConfig;
