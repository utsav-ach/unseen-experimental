The sql has been a whole mess, we will clean up the sql side

# Plan
## 1. Remove all existing rpc
the rpc are the main culprit of the unmaintainable code. so we remove all of them and will make them from scratch.

## 2. First make some common rpc for validation and permissions
### Validation Rpc example
the following is an example of validation rpc::

```SQL
CREATE OR REPLACE FUNCTION clean_text(value text, field_name text)
RETURNS text AS $$
BEGIN
  IF value IS NULL OR length(trim(value)) = 0 THEN
    RAISE EXCEPTION '% is required and cannot be empty.', field_name;
  END IF;

  RETURN trim(value);
END;
$$ LANGUAGE plpgsql;
```
Dont be just limited to this much,  there are many thing we can validate,
some of them but not limited to are, email, password, phone no (to contain country code),  json_range and many more.

if you ever feel like doing validation which you will definately will,  you use this function its simple and avoids writing same code each time, 

### permissions utils rpc
same as for validation we also need to check for permission
for e.g, some of the access is only for admin or self, 
lets say you want to edit your profile then it is allowed by only admin or self so that check must be passed.

A example of permission rpc includes::
```sql
CREATE OR REPLACE FUNCTION public.require_self_or_admin_access(
  p_id uuid,
  message text DEFAULT 'Unauthorized: You can only access your own data.'
)
RETURNS void
LANGUAGE plpgsql
STABLE
AS $$
BEGIN
  IF p_id IS NULL THEN
    RAISE EXCEPTION 'Target user id is required.' USING ERRCODE = '22004';
  END IF;

  IF NOT public.is_admin_or_self(p_id) THEN
    RAISE EXCEPTION '%', COALESCE(NULLIF(message, ''), 'Unauthorized: You can only access your own data.') USING ERRCODE = '42501';
  END IF;
END;
$$;

CREATE OR REPLACE FUNCTION public.is_admin_or_self(p_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
AS $$
    -- COmplete logic here
$$;
```

Note:: You might just implement these functions and repeat the permision and validation in other place but never do that,  for validation and permission you should not repeat the logic at all. 


## New RPC
as we will be removing each and every rpc file and remake them, we will now dont make them spllitted. 

for clarity and sake of ease we will me writing logic in same file for rpcs.

### New Rpc Styles
The main rule of the new rpc are `avoid those oversized page-aggregator RPCs`. 
 
#### 1. Post/data rpc
these are special rpc which will be used to do inserts in the db. e.g, onbording or sending guide application,

There are limited of these input releted rpcs like::
1. Upsert profile (special logic rpc, it takes the necessary params defaults to null by default, if the onbording is already complete of the current user then it treates the function as update function where partial data is given, but if onbording is not complete then it is strict it will need all the params,  this is a important rpc and should be reliable),
2. apply for guide (single rpc taks both params and list of application service area objects),
3. review guide (if same guide was reviewed by same user then update it, only the user who has booked the guide in past can review them)
4. start negotiation (the start of the negotiation by tourist with necessary params,  if negotiation to same guide is pending then we wont allow)
5. reject negotiation (same rpc for both guide and tourist for cancellation rpc auto finds either the guide is cncelling or tourist via auth.uid, the remarks is mandatory)
6. offer terms (terms must be offered by the guide only)
7. accept guide terms (the tourist accepts the term of guide and then gives a remarks)

There were some general purpose of rpc, 
some rpc are for admin and strictly admin only
1. add destination
2. add package (same for both destination and activity package)
3. suspend guide
4. update guide application (same for approve and reject in either case remarks is mandatory)


RPC alone are not enough, RLS is also needed equally, 
for simple insert or update where there is no need to update multiple tables or no heavy business logic we will use direct insert and the use of RLS, We wont `overengineer rpc` everywhere.

“Use RPC only when business logic or validation is required beyond RLS”

#### 2. fetch rpc
Note that fetching dont need rpc 95% of the times, we will use VIEWS and RLS combination.


Short answer: **No, you don’t need RPC for everythin

Let’s clear the confusion properly 

# Rule of thumb (keep this)

# Do you need RPC for simple filtering?

### NO — for this case:

```sql id="0p3m1f"
SELECT * FROM available_guides
```
is **perfectly fine**
---

# When views are BETTER than RPC
### ✔ Public listing (guides, destinations)

* simple filters
* no auth logic
* no mutations
 
**Views are superior**

* faster
* cacheable
* simpler
* less boilerplate

# When you SHOULD use RPC

Use RPC only when you need:

### 1. Auth-dependent logic

```sql
WHERE user_id = auth.uid()
```

### 2. Business rules

```sql
IF guide is suspended → return empty
```

### 3. Computation / aggregation

```sql
distance calculation
ranking logic
recommendation system
```

### 4. Writes with logic

```sql
create booking
apply for guide
complete onboarding
```

# Important insight (this is key)

thinking that:
> “RPC is better than direct query”

That’s only **half true**.
---

# ⚡ Performance & security

### Views are safe IF:

* RLS is applied on underlying tables
* or view itself is safe

### Supabase handles:

* auth via JWT
* RLS enforcement

So:
calling `.from("available_guides")` is **not unsafe**
---

# important Note
Don’t over-engineer with RPC everywhere.
That’s **clean database design**, not beginner stuff.
---
