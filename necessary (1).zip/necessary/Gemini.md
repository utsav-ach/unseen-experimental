# Unseen Nepal

Unseen Nepal is a travel destination application designed to connect travelers with local guides, exploring both popular and hidden gems of Nepal. Built with a modern tech stack, it prioritizes performance, SEO, and a realistic booking experience.

---

## Tech Stack
- **Framework:** Next.js (App Router)
- **Styling:** Tailwind CSS
- **UI Components:** Shadcn UI
- **Backend/Database:** Supabase (PostgreSQL)
- **State Management:** Zustand
- **Package Manager:** `bun` (Strictly required)

---

## App Features

### 1. Destination Discovery
- **Featured Locations:** Admins register top travel spots for users to browse.
- **Map Selection:** Users aren't limited to featured spots. They can pick any coordinate using a custom map selection tool (`components/map/selection-map.tsx`).
- **Geo-spatial Matching:** The app uses location data to find guides whose service areas cover the user's chosen spot.

### 2. Guide System
- **Becoming a Guide:** Users must apply to be guides. Admins review applications and provide feedback (Accept/Reject) with personalized messages.
- **Guide Dashboard:** Approved guides get a dedicated dashboard to manage hire requests and travel details.

### 3. The Three-Step Negotiation (TSN)
Booking is not instant; it follows a realistic 3-step flow to respect the guide's effort and the traveler's needs:
1.  **Hire Request:** User sends a request with destination details, number of people, duration, and remarks.
2.  **Guide Review:** The guide reviews the request. They can reject it or accept it by providing:
    - Custom Remarks
    - Total Fees (Pricing is flexible based on the trip's difficulty)
    - Minimum Pre-Payment amount
3.  **Completion:** The user reviews the guide's offer. They can either cancel the negotiation or complete the booking by paying any amount between the *Pre-Payment* minimum and the *Total Fees* maximum.

### 4. Travel Packages & Activities
- **Predefined Blueprints:** Admins create fixed-price travel packages with preset destinations, routes, and member capacities.
- **Direct Booking:** Unlike the custom guide discovery, packages skip negotiation and go directly to checkout.
- **Activity Mapping:** Destinations and packages are linked to a global activity catalog (e.g., "Trekking", "Paragliding") for rich discovery options.

---

## Architectural Rules (The "Strict" Way)

To keep the codebase clean and scalable, we follow these non-negotiable rules:

### 1. The Logic Flow
**UI → Stores → Services → RPC/Database**
- **UI Components:** Never call APIs or services directly. They only talk to Stores.
- **Stores (Zustand):** Manage state and communicate with dedicated services.
- **Services:** Abstracted classes (extending `SupabaseService`) that handle data fetching.
- **Backend Encapsulation:** Complex logic belongs in **Postgres RPCs**, not the frontend.

### 2. DRY & UI Standards
- **Shadcn First:** Check `components/ui` before building anything.
- **Abstracted Inputs:** Use `components/onboarding/input-field.tsx` for form consistency.
- **No Hardcoded Colors:** Always use CSS variables (e.g., `bg-background`, `text-primary`).
- **Dark Mode:** Every component must support dark mode and be fully responsive.

### 3. SEO & Semantics
- **SEO is Priority #1:** Every page component must include a `Metadata` definition.
- **Semantic HTML:** Use `main`, `article`, and `section` tags properly.

### 4. Protected Routes
- Use the `Guard` component from `components/auth/auth-initializer.tsx` to protect specific pages (e.g., Guide Dashboard, Booking Page). Do not wrap the whole app; keep it granular.

---

##  Database & Backend

### Directory Structure
The `sql/` directory is the brain of the app:
- `schema/`: Main table structures and indexes.
- `rpc/`: All remote procedure calls (complex logic stays here).
- `rls/`: Row Level Security policies per module.
- `backend/schemas.ts`: A single source of truth for all **Zod schemas**. This must stay in sync with your SQL tables and RPCs.

### Media Handling
- **Public Buckets:** For destinations, stories, and profiles.
- **Vault Bucket:** For sensitive data like Guide ID documents (protected by RLS).

---

## Error Handling
- **No Silent Failures:** Users must know exactly what went wrong.
- **UI Feedback:** Use `toast.success` and `toast.error`.
- **Form Validation:** Every input field must have a dedicated error display area using the standard styling (destructive/red).

---

## Developer Reminders
- **BUN ONLY:** Do not use npm or yarn.
- **Performance:** If a page needs data from multiple tables, write an **RPC** to fetch it in one single database hit.
- **Documentation:** If you change a schema or service, update the `AGENTS.md` or `Gemini.md` immediately.
- **Manifest sync update (2026-04-08):** Trek-Dai details page now uses `useGuideStore.fetchGuideDetail()` to enforce `UI -> Store -> Service` and avoid direct service calls in UI.
- **Manifest sync update (2026-04-08):** Guide request RPCs use `sql/rpc/guide-dashboard-rpc.sql` as canonical source; duplicate names in `sql/rpc/negotiation-details-rpc.sql` were deprecated/renamed to avoid override conflicts.
- **Manifest sync update (2026-04-08):** Photos gallery now uses `backend/services/photoService.ts` and `backend/stores/usePhotoStore.ts` with `sql/schema/photos.sql`, `sql/rpc/photos-rpc.sql`, `sql/rls/photos-rls.sql`, and the public `user-gallery` bucket for uploads.

- **Manifest sync update (2026-04-08):** User-gallery files are stored under an owner-first path (`<user-id>/photos/public`) to satisfy storage RLS, and the photo upload dialog is intentionally preview-first with hidden optional description/location sections.

- **Manifest sync update (2026-04-08):** `public.photos` needs explicit grants (`SELECT` for `anon/authenticated`, `INSERT/UPDATE/DELETE` for `authenticated`) in addition to RLS because table privileges are separate from row policies.

---

## Folder Organization
- `backend/`: Services and Zustand Stores.
- `components/<module>/`: Components specific to a feature (e.g., `components/destinations/`).
- `supabase/`: Base service classes and Supabase configuration.
- `sql/`: All PostgreSQL code (Schemas, RLS, RPCs).