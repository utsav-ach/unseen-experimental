
	Write-Host "Enter the commit message: "
	$message = Read-Host "Commit message"
	git add .
	git commit -m "$message"	
	