#!/bin/bash
set -ex

echo "Starting setup script for DEBIAN based systems..."

# Check and install git
if ! command -v git &> /dev/null; then
    echo "Git is not installed. Installing git via apt..."
    sudo apt update
    sudo apt install -y git
else
    echo "Git is already installed."
fi

# Clone repository
TARGET_DIR="$HOME/Desktop/unseen-nepal-frontend"

if [ -d "$TARGET_DIR" ]; then
    echo "Directory $TARGET_DIR already exists. Skipping git clone."
else
    echo "Cloning unseen-nepal-frontend into $TARGET_DIR..."
    git clone https://github.com/Utsav-56/unseen-nepal-frontend.git "$TARGET_DIR"
fi

# Check and install bun (using official bun.sh url as bun.com redirects)
if ! command -v bun &> /dev/null; then
    echo "Bun is not installed. Installing bun..."
    curl -fsSL https://bun.sh/install | bash
    
    # Export path explicitly for the remainder of this script execution
    export BUN_INSTALL="$HOME/.bun"
    export PATH="$BUN_INSTALL/bin:$PATH"
    
    echo "Sourcing ~/.bashrc..."
    if [ -f "$HOME/.bashrc" ]; then
        source "$HOME/.bashrc"
    fi
else
    echo "Bun is already installed."
fi

# Setup project
echo "Entering directory $TARGET_DIR..."
cd "$TARGET_DIR"

echo "Running bun install to install project dependencies..."
bun install

echo "Creating the ./commit helper script..."
cat << 'EOF' > commit
#!/bin/bash

echo "Enter the commit message: "
read message
git add .
git commit -m "$message"
EOF

echo "Making ./commit executable..."
chmod +x commit 

# remove the setup script
rm setup.sh


# if vs code available open the project in vs code
if command -v code &> /dev/null; then
    echo "VS Code is available. Opening the project..."
    code .
fi


echo "Setup script finished successfully."
