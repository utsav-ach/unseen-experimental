# Unseen Nepal — Admin Design Blueprint (AI Agent Instruction)

This document is the execution-grade design and architecture instruction for building the full admin panel of Unseen Nepal. It is not only a UI brief. It is a product + data + backend + execution guideline so an AI agent can implement the admin system in a stable, scalable and policy-safe way.

The admin panel must follow the same strict rules from AGENTS.md:

- UI must stay clean and minimal.
- Use shadcn as first preference for reusable UI.
- No business logic in UI.
- Mandatory architecture flow: **UI → Store → Service → RPC/DB**.
- No hardcoded colors; use theme tokens.
- Strong SEO and Metadata handling for route-level layouts.
- Strong error visibility (`toast.success`, `toast.error`, inline error blocks).

---

## 1) Why admin panel exists in this project

Unseen Nepal is content + operations heavy. Public pages are driven by data that must be curated, moderated, approved, and measured daily. Without a proper admin panel, the travel flow breaks across every core module: destinations, packages, activities, guides, bookings, stories, and photos.

Admin panel in this app is not only for analytics. It must become the operational backbone that:

1. Curates what users see publicly.
2. Reviews guide applications and trust-critical identity artifacts.
3. Moderates community content.
4. Monitors booking and negotiation health.
5. Controls access and roles for internal operators.
6. Gives fast insights from pre-aggregated analytics.

---

## 2) Current project analysis summary (what already exists)

### Existing admin implementation

- Only one admin route exists now: `app/admin/dashboard/page.tsx`.
- It uses `Guard` with `requireAdmin` inside `components/admin/admin-dashboard.tsx`.
- Store/service already exists for basic stats:
  - `backend/stores/useAdminStore.ts`
  - `backend/services/adminService.ts`
- RPC exists: `sql/rpc/admin-rpc.sql` (`get_admin_stats`).

### Existing domain modules that admin must control

From routes, stores, services and SQL/RLS analysis:

- **Featured destinations** (publicly consumed in home/destinations pages)
- **Activities** (public listing + activity detail pages)
- **Travel packages** (public listing + direct booking flow)
- **Guide applications** (approval/rejection required)
- **Guides and service availability data**
- **Booking requests + bookings** (negotiation + finalized)
- **Stories** (community feed + detail)
- **Photos** (community gallery)
- **Profiles/users/roles** (admin and guide role governance)
- **Reviews and interaction metrics**

### Existing RLS already indicates admin ownership

RLS already defines admin capabilities on these core tables:

- `featured_destinations`
- `activities`
- `travel_packages`
- `guide_applications`
- `bookings` (view access)
- `photos` (owner/admin moderation)
- storage vault object access for admins

This means backend intent already supports a broader admin panel; frontend is simply incomplete.

---

## 3) Page-by-page mapping: where admin-managed data is used

This section tells the AI agent what public/protected pages are consuming data that should be admin-manageable.

### A) Discover & conversion pages

1. `/` home page:
	- Featured destinations
	- Featured packages
	- Featured stories
	- These are all admin-curated surfaces.

2. `/destinations`, `/destinations/[id]`, `/destinations/map`:
	- Destinations and map-relevant destination metadata.
	- Admin controls destination quality and tags.

3. `/activities`, `/activities/details/[id]`:
	- Activity records and destination linkage.
	- Admin creates activity catalog and taxonomy.

4. `/packages`, `/packages/details/[id]`:
	- Package pricing, capacity, itinerary, media.
	- Admin controls direct-booking offerings.

### B) Guide lifecycle pages

1. `/guide/register`, `/guide/register/status`:
	- Guide application entries are submitted by users.
	- Admin approves/rejects and gives feedback.

2. `/trek-dai`, `/trek-dai/details/[id]`:
	- Guide listing quality depends on admin-approved guide base.

### C) Booking/negotiation pages

1. `/bookings`, `/bookings/details/[id]`, `/bookings/checkout/[id]`
2. `/guide/requests`, `/guide/requests/[id]`
3. `/profile/requests`

These pages depend on booking request state transitions and finalized bookings. Admin needs oversight, dispute visibility, and operational metrics.

### D) Community pages

1. `/stories`, `/stories/[id]`, `/stories/add`, `/stories/edit/[id]`
2. `/photos`, `/photos/[id]`

Admin needs moderation controls for harmful/spam/illegal content and policy enforcement.

### E) User/account integrity pages

1. `/profile`, `/profile/edit`
2. Auth onboarding/verification flow

Admin needs controlled role management (`tourist`, `guide`, `admin`) and account state inspection (without exposing passwords/secrets).

---

## 4) Required admin panel pages (target IA)

Use route group under `/admin` with dedicated layout. Keep navbar minimal and put navigation in sidebar.

### Mandatory pages

1. **Dashboard** — `/admin/dashboard`
	- KPIs, trend charts, pending queues, alerts.

2. **Guide Applications** — `/admin/guides/applications`
	- Filter by status (`pending`, `approved`, `rejected`).
	- Document preview with signed URLs.
	- Approve/reject with mandatory feedback.

3. **Destinations Manager** — `/admin/destinations`
	- CRUD for featured destinations.
	- Manage tags, radius, images, geolocation, activities mapping.

4. **Activities Manager** — `/admin/activities`
	- CRUD for activities.
	- Linkage visibility to destinations/packages.

5. **Packages Manager** — `/admin/packages`
	- CRUD for travel packages.
	- Price, images, route text, featured flag, member constraints.

6. **Bookings & Negotiations Monitor** — `/admin/bookings`
	- Unified operational table for booking requests + finalized bookings.
	- Status filters, amount filters, date range, escalation flags.

7. **Stories Moderation** — `/admin/stories`
	- Archive/unarchive/remove actions.
	- Search and report-driven moderation queue.

8. **Photos Moderation** — `/admin/photos`
	- Remove or review suspicious uploads.
	- Filter by uploader, date, location.

9. **Users & Roles** — `/admin/users`
	- User list, profile summary, verify flags.
	- Promote/demote admin (strict audit).
	- Role corrections (`tourist`/`guide`/`admin`) under policy.

10. **Admin Settings / System Ops** — `/admin/settings`
	- Analytics retention settings
	- Aggregation health checks
	- Feature toggles (if introduced later)

---

## 5) Feature specification by domain

### 5.1 Dashboard features

Must include:

- 24h, 7d, 30d switch.
- New accounts, stories, photos, booking requests, confirmed bookings.
- Pending guide applications.
- Revenue indicators from booking totals/prepay aggregates.
- Top requested destinations and top requested guides.
- Interaction metrics (likes + comments).

Important: near-real-time endpoints are expensive for long windows. Use pre-aggregated daily stats table + lightweight RPC for recent deltas.

### 5.2 Guide application management

- Queue-first UX: pending appears first.
- Application detail drawer/page with:
  - profile snapshot
  - submitted identity meta
  - signed vault document preview
- Mandatory feedback input on approve/reject.
- Auto refresh list after decision.

### 5.3 Content management (destinations/activities/packages)

- Reusable table + filters + pagination.
- Reusable form layer using existing input abstractions (`components/onboarding/input-field.tsx` where fit).
- Media upload with clear constraints.
- Strict client validation + backend zod validation.

### 5.4 Community moderation (stories/photos)

- Queue of latest + most-reported + high-engagement posts.
- One-click moderation actions with confirmation dialogs.
- Safe action model:
  - soft archive for stories
  - delete with explicit confirm for photos
- Keep moderation reason optional for now, but log internally.

### 5.5 Bookings operations

- Cross-status operational board:
  - pending negotiation
  - guide approved / rejected
  - confirmed / cancelled
  - completed (bookings)
- Export-ready table state (future CSV).
- Amount + timeline analytics.

### 5.6 User and role governance

- Search by email/username/id.
- Show flags: verified, guide, admin, onboarding done.
- Promote to admin requires explicit confirmation and audit record.
- Never expose auth secrets or password hashes.

---

## 6) Architecture rules for implementation (non-negotiable)

### 6.1 Layering

- **UI Layer**: only calls store hooks and store actions.
- **Store Layer**: orchestrates UX state, loading, filters, table state.
- **Service Layer**: transport + RPC calls + validation.
- **DB/RPC Layer**: heavy joins, analytics aggregation, policy-sensitive operations.

No direct service calls from UI.

### 6.2 Admin module structure

Create dedicated admin module sets:

- `backend/services/admin*.ts` (split by concern if needed)
- `backend/stores/useAdmin*.ts`
- `components/admin/*`
- `app/admin/*`

Prefer domain-focused splits over one giant store.

### 6.3 RPC-first backend encapsulation

For admin pages, use RPCs for:

- joined tables
- heavy counts
- filtered aggregate data
- dashboard hydration payloads

When creating/changing RPC:

1. Add SQL in modular `sql/rpc/*` files.
2. Update zod contracts in `backend/schemas.ts`.
3. Align service return typing.

---

## 7) Reusability and DRY plan (must implement)

Build reusable admin primitives once, then reuse everywhere:

1. `AdminPageHeader`
2. `AdminMetricCard`
3. `AdminDataTable<T>` (generic)
4. `AdminFilterBar`
5. `AdminStatusBadge`
6. `AdminErrorPanel`
7. `AdminEmptyState`
8. `AdminConfirmDialog`
9. `AdminFormSheet` or `AdminFormDialog`

Use shadcn components (`table`, `tabs`, `dialog`, `sheet`, `form`, `alert`, `badge`, `dropdown-menu`, `pagination`, `skeleton`) instead of custom rebuilding.

---

## 8) Performance and optimization strategy

### 8.1 Data fetching strategy

- Server-side pagination for large lists (users, bookings, content).
- Filter and sort at query/RPC level (not only client-side).
- Debounced search inputs for query-heavy pages.
- Cache stable lists in stores with TTL where safe.

### 8.2 Analytics strategy (critical)

Implement daily aggregate storage table (e.g. `app_analytics_stats`) updated by scheduled job (Supabase scheduled function / cron) at Nepal timezone boundary.

Store daily metrics so dashboard reads become lightweight and chart-ready. Do not recalculate expensive full-window analytics on every page open.

### 8.3 DB and index strategy

- Ensure indexes for date/status filter columns used in admin queries.
- Keep aggregate tables date-indexed.
- Use RPCs for multi-table hydration to minimize round trips.

### 8.4 UI responsiveness

- Use skeleton states for tables/cards.
- Use optimistic local updates only for safe actions.
- After mutations, re-fetch targeted dataset (not full dashboard globally unless needed).

---

## 9) Security and compliance strategy

1. **Route security**
	- Every admin page must be wrapped with `Guard requireLogin requireAdmin`.

2. **RLS safety**
	- Keep RLS as source of truth.
	- For privileged aggregates, use SECURITY DEFINER RPC with explicit admin check.

3. **Vault media handling**
	- Identity docs must stay in `vault`.
	- Preview only through signed URLs with short expiry.

4. **Auditability**
	- Every sensitive admin mutation should be logged in an audit table (future-proof requirement, should be planned now).

5. **Privacy boundaries**
	- Never expose secret auth fields.
	- Only operationally required profile fields should be shown.

---

## 10) SEO and metadata behavior for admin routes

Admin routes are protected/internal, but still must follow Next metadata rules:

- Put metadata in route layout files where page is client component.
- Set `robots: { index: false, follow: false }` for admin route layouts.
- Use semantic sections (`main`, `section`, `article`) for structure and accessibility.

---

## 11) UI and design language rules for admin

Admin UI should remain minimal and readable (not flashy). Keep spacing breathable, text clear, and actions obvious.

- Sidebar + top strip layout.
- No hardcoded colors (`bg-white`, etc.).
- Use theme tokens (`bg-background`, `text-foreground`, `border-border`).
- Tables should be clean with compact controls.
- Card corners should stay moderate (not overly rounded).
- Whole cards clickable when card navigation is intended.

---

## 12) Execution roadmap (phase-by-phase)

### Phase 1 — Foundation

- Create `/admin/layout.tsx` with sidebar shell and metadata noindex.
- Build reusable admin UI primitives.
- Refactor existing dashboard page into new shell.

### Phase 2 — Core operations

- Implement guide applications admin page.
- Implement destinations, activities, packages CRUD pages.

### Phase 3 — Moderation + operations

- Implement stories moderation page.
- Implement photos moderation page.
- Implement bookings/negotiations monitor.

### Phase 4 — Governance + analytics expansion

- Implement users/roles page.
- Introduce audit log mechanics.
- Add pre-aggregated analytics table and scheduler.

### Phase 5 — Hardening

- Type and zod alignment checks.
- Error-state UX pass.
- Performance pass (query plans, pagination, cache).
- Final TS check.

---

## 13) Acceptance checklist (definition of done)

- Admin panel has dedicated layout and navigation.
- All key domains have admin pages.
- No UI-to-service direct calls.
- Stores/services are modular and typed.
- RPC + zod schemas are synchronized for new payloads.
- All admin routes are protected via Guard admin checks.
- All forms have visible inline error areas and toasts.
- Dashboard uses optimized analytics strategy (including daily aggregates plan).
- Metadata and robots behavior is correctly configured.
- Build passes TypeScript checks with no new errors.

---

## 14) Final implementation note to AI agent

Build this admin panel as an operational product, not a single page. Keep design minimal, consistent with the main app, and centered on clarity and speed. Reuse shadcn and existing abstractions aggressively. Any new heavy data requirement should be solved with RPC-first backend encapsulation and reflected in `backend/schemas.ts` before UI consumption.

