#!/bin/bash
set -e

echo "Step 1: Building the project (assumes standalone mode is set in next.config.ts)..."
bun run build

echo "Step 2: Preparing standalone directory structure..."
# Next.js standalone mode does not include static assets automatically.
# We must copy them into the standalone directory before compressing.
cp -r public .next/standalone/ || true
mkdir -p .next/standalone/.next
cp -r .next/static .next/standalone/.next/

echo "Step 3: Compressing the standalone build..."
# Compress everything INSIDE the standalone directory
tar -czf unseen-build.tar.gz -C .next/standalone .

echo "Step 4: Preparing the remote directory..."
# The SCP error happened because the folder didn't exist over on the server!
ssh dovps "mkdir -p /root/unseen-nepal-frontend"

echo "Step 5: Pushing the compressed build securely to dovps..."
scp unseen-build.tar.gz dovps:/root/unseen-nepal-frontend/
scp .env.local dovps:/root/unseen-nepal-frontend/

echo "Step 6: Extracting on dovps and restarting unseen-frontend service..."
ssh dovps "cd /root/unseen-nepal-frontend && tar -xzf unseen-build.tar.gz && rm unseen-build.tar.gz && systemctl restart unseen-frontend"

echo "Step 7: Cleaning up local artifacts..."
rm unseen-build.tar.gz

echo "Server-ready standalone deployment complete!"


